# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from wot_api.test import BaseTestCase


class TestDefaultController(BaseTestCase):
    """DefaultController integration test stubs"""

    def test_get_lights(self):
        """Test case for get_lights

        GetLights request on device LightSensor1
        """
        response = self.client.open(
            '/api/lights',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_heating_off(self):
        """Test case for heating_off

        heating_off request on device relay heating
        """
        response = self.client.open(
            '/api/heating/off',
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_heating_on(self):
        """Test case for heating_on

        heating_on request on device relay heating
        """
        data = dict(power=3.4)
        response = self.client.open(
            '/api/heating/on',
            method='POST',
            data=data,
            content_type='application/x-www-form-urlencoded')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_shades_close(self):
        """Test case for shades_close

        ShadesClose request on device shades
        """
        response = self.client.open(
            '/api/shades/ToggleAndLower',
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_shades_open(self):
        """Test case for shades_open

        ShadesOpen request on device shades
        """
        response = self.client.open(
            '/api/shades/ToggleAndHigher',
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_switch_off_lamp(self):
        """Test case for switch_off_lamp

        SwitchOffLamp request on device philipshue
        """
        response = self.client.open(
            '/api/lights/ToggleAndLower',
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_switch_on_lamp(self):
        """Test case for switch_on_lamp

        SwitchOnLamp request on device philipshue
        """
        response = self.client.open(
            '/api/lights/ToggleAndHigher',
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_switch_tv_off(self):
        """Test case for switch_tv_off

        SwitchTvOff request on device samsungTV
        """
        response = self.client.open(
            '/api/offof',
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_switch_tv_on(self):
        """Test case for switch_tv_on

        SwitchTVOn request on device samsungTV
        """
        query_string = [('query_param1', 'query_param1_example')]
        response = self.client.open(
            '/api/TV/very/long/path/{path-param}/needed/on'.format(path_param='path_param_example'),
            method='POST',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
